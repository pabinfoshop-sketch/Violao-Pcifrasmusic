#!/usr/bin/env bash
set -euo pipefail

if ! command -v gh >/dev/null 2>&1; then
  echo "ERRO: GitHub CLI (gh) não está instalado. Instale em: https://cli.github.com/" >&2
  exit 1
fi

if ! gh auth status >/dev/null 2>&1; then
  echo "Faça login no GitHub primeiro: gh auth login" >&2
  exit 1
fi

read -r -p "DOMAIN [https://app-cifra.fly.dev]: " DOMAIN
DOMAIN=${DOMAIN:-https://app-cifra.fly.dev}

read -r -p "FLY_API_TOKEN: " FLY_API_TOKEN
read -r -s -p "JWT_SECRET (enter para gerar automático): " JWT_SECRET
echo
if [ -z "$JWT_SECRET" ]; then
  if command -v openssl >/dev/null 2>&1; then
    JWT_SECRET=$(openssl rand -hex 32)
  else
    JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  fi
  echo "JWT_SECRET gerado automaticamente."
fi

read -r -p "MP_ACCESS_TOKEN (TEST-*): " MP_ACCESS_TOKEN
read -r -p "MP_PUBLIC_KEY (TEST-*): " MP_PUBLIC_KEY

printf '%s' "$FLY_API_TOKEN" | gh secret set FLY_API_TOKEN
printf '%s' "$JWT_SECRET" | gh secret set JWT_SECRET
printf '%s' "$DOMAIN" | gh secret set DOMAIN
printf '%s' "$MP_ACCESS_TOKEN" | gh secret set MP_ACCESS_TOKEN
printf '%s' "$MP_PUBLIC_KEY" | gh secret set MP_PUBLIC_KEY

echo "✅ Secrets configurados no GitHub Actions."
echo "Agora rode: git push origin main"
echo "Ou dispare manualmente: GitHub > Actions > Fly Deploy > Run workflow"
