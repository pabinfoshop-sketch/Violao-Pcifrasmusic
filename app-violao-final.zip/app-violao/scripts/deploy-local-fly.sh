#!/usr/bin/env bash
set -euo pipefail

if ! command -v flyctl >/dev/null 2>&1; then
  echo "ERRO: flyctl não está instalado. Instale com:" >&2
  echo "curl -L https://fly.io/install.sh | sh" >&2
  exit 1
fi

if ! flyctl auth whoami >/dev/null 2>&1; then
  echo "Faça login no Fly primeiro: fly auth login" >&2
  exit 1
fi

read -r -p "DOMAIN [https://app-cifra.fly.dev]: " DOMAIN
DOMAIN=${DOMAIN:-https://app-cifra.fly.dev}

read -r -s -p "JWT_SECRET (enter para gerar automático): " JWT_SECRET
echo
if [ -z "$JWT_SECRET" ]; then
  if command -v openssl >/dev/null 2>&1; then
    JWT_SECRET=$(openssl rand -hex 32)
  else
    JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  fi
  echo "JWT_SECRET gerado automaticamente."
fi

read -r -p "MP_ACCESS_TOKEN (TEST-*): " MP_ACCESS_TOKEN
read -r -p "MP_PUBLIC_KEY (TEST-*): " MP_PUBLIC_KEY

flyctl apps create app-cifra --org personal || true
flyctl secrets set \
  JWT_SECRET="$JWT_SECRET" \
  DOMAIN="$DOMAIN" \
  MP_ACCESS_TOKEN="$MP_ACCESS_TOKEN" \
  MP_PUBLIC_KEY="$MP_PUBLIC_KEY" \
  --stage

flyctl deploy --remote-only --config fly.toml

echo "✅ Deploy concluído. Abra: $DOMAIN"
