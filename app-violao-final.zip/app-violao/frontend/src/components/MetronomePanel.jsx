import { useCallback, useEffect, useRef, useState } from 'react'

/**
 * MetronomePanel — Tela 7 do design Cyber Luthier.
 * Painel dedicado de metrônomo com tap-tempo, seletor de compasso,
 * acento no primeiro tempo e BPM em neon.
 *
 * Uso:
 *   <MetronomePanel open={showMetronome} onClose={() => setShowMetronome(false)} />
 *
 * Sem dependências externas — usa WebAudio para o click.
 */
export default function MetronomePanel({ open, onClose, initialBpm = 90 }) {
  const [bpm, setBpm] = useState(initialBpm)
  const [signature, setSignature] = useState('4/4') // '2/4' | '3/4' | '4/4' | '6/8'
  const [playing, setPlaying] = useState(false)
  const [accentFirst, setAccentFirst] = useState(true)
  const [beat, setBeat] = useState(0)

  const audioCtxRef = useRef(null)
  const tickTimerRef = useRef(null)
  const tapsRef = useRef([])

  const beatsPerBar = signature === '2/4' ? 2 : signature === '3/4' ? 3 : signature === '6/8' ? 6 : 4

  // --- WebAudio click ----------------------------------------------------
  const ensureCtx = useCallback(() => {
    if (!audioCtxRef.current) {
      const AC = window.AudioContext || window.webkitAudioContext
      audioCtxRef.current = new AC()
    }
    return audioCtxRef.current
  }, [])

  const click = useCallback((accented) => {
    const ctx = ensureCtx()
    const t = ctx.currentTime
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.frequency.value = accented ? 1500 : 900
    osc.type = 'square'
    gain.gain.setValueAtTime(0.0001, t)
    gain.gain.exponentialRampToValueAtTime(accented ? 0.5 : 0.3, t + 0.005)
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.06)
    osc.connect(gain).connect(ctx.destination)
    osc.start(t)
    osc.stop(t + 0.08)
  }, [ensureCtx])

  // --- Loop de batida ----------------------------------------------------
  useEffect(() => {
    if (!playing) {
      clearInterval(tickTimerRef.current)
      tickTimerRef.current = null
      setBeat(0)
      return
    }
    const ms = 60000 / Math.max(30, Math.min(240, bpm))
    let local = 0
    click(accentFirst && local === 0)
    setBeat(0)
    tickTimerRef.current = setInterval(() => {
      local = (local + 1) % beatsPerBar
      setBeat(local)
      click(accentFirst && local === 0)
    }, ms)
    return () => clearInterval(tickTimerRef.current)
  }, [playing, bpm, beatsPerBar, accentFirst, click])

  // --- Tap tempo ---------------------------------------------------------
  const tap = useCallback(() => {
    const now = performance.now()
    tapsRef.current = [...tapsRef.current, now].filter(t => now - t < 3000)
    const taps = tapsRef.current
    if (taps.length >= 2) {
      const diffs = taps.slice(1).map((t, i) => t - taps[i])
      const avg = diffs.reduce((a, b) => a + b, 0) / diffs.length
      const next = Math.round(60000 / avg)
      if (next >= 30 && next <= 240) setBpm(next)
    }
  }, [])

  // --- Atalhos teclado ---------------------------------------------------
  useEffect(() => {
    if (!open) return
    const h = (e) => {
      if (e.key === ' ') { e.preventDefault(); setPlaying(p => !p) }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setBpm(b => Math.min(240, b + 1)) }
      else if (e.key === 'ArrowDown') { e.preventDefault(); setBpm(b => Math.max(30, b - 1)) }
      else if (e.key === 't' || e.key === 'T') tap()
      else if (e.key === 'Escape') onClose?.()
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [open, tap, onClose])

  if (!open) return null

  return (
    <div className="modal-overlay metronome-overlay" onClick={onClose}>
      <div className="modal-inner metronome-panel" onClick={e => e.stopPropagation()}>
        <div className="metronome-topbar">
          <span className="modal-title">Metrônomo</span>
          <button className="tuner-new-close" onClick={onClose} aria-label="Fechar">×</button>
        </div>

        <div className="metronome-bpm-row">
          <button
            className="action-btn metronome-step"
            onClick={() => setBpm(b => Math.max(30, b - 1))}
            aria-label="Diminuir BPM"
          >−</button>
          <div className="metronome-bpm" role="status" aria-live="polite">
            <span className="bpm-value">{bpm}</span>
            <span className="metronome-bpm-label">BPM</span>
          </div>
          <button
            className="action-btn metronome-step"
            onClick={() => setBpm(b => Math.min(240, b + 1))}
            aria-label="Aumentar BPM"
          >+</button>
        </div>

        <input
          type="range"
          min={30}
          max={240}
          value={bpm}
          onChange={e => setBpm(parseInt(e.target.value, 10))}
          className="metronome-slider"
          aria-label="BPM"
        />

        <div className="metronome-beats" aria-hidden="true">
          {Array.from({ length: beatsPerBar }).map((_, i) => (
            <span
              key={i}
              className={`strum-beat ${beat === i && playing ? 'active' : ''} ${i === 0 && accentFirst ? 'accent' : ''}`}
            />
          ))}
        </div>

        <div className="metronome-controls">
          <label className="metronome-field">
            <span>Compasso</span>
            <select
              value={signature}
              onChange={e => setSignature(e.target.value)}
              className="metronome-select"
            >
              <option value="2/4">2/4</option>
              <option value="3/4">3/4</option>
              <option value="4/4">4/4</option>
              <option value="6/8">6/8</option>
            </select>
          </label>

          <label className="metronome-field metronome-toggle">
            <input
              type="checkbox"
              checked={accentFirst}
              onChange={e => setAccentFirst(e.target.checked)}
            />
            <span>Acentuar 1º tempo</span>
          </label>
        </div>

        <div className="metronome-actions">
          <button
            className={`action-btn ${playing ? 'active-action' : ''}`}
            onClick={() => setPlaying(p => !p)}
          >
            {playing ? '■ Parar' : '► Tocar'}
          </button>
          <button className="action-btn" onClick={tap}>
            Tap (T)
          </button>
        </div>

        <p className="metronome-hint">
          Espaço = play/pausa · ↑/↓ = BPM · T = tap-tempo · Esc = fechar
        </p>
      </div>
    </div>
  )
}
