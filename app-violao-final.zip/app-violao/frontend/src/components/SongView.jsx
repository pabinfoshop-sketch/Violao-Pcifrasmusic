import { useState, useMemo, useEffect } from 'react'
import { transposeChord } from '../utils/chords'
import { STRUM_PRESETS } from '../utils/chords'
import { simplifyChord, getChordVariants } from '../utils/chordDiagrams'
import ChordDiagram from './ChordDiagram'

function isTabLine(text) {
  return /^[EeADGB]\|[:=.\-0-9|()hps/\\]*\|?\s*$/.test(text.trim())
}

export default function SongView({ song, transpose, viewMode, studyMode, currentKey, onToggleFavorite, onExport }) {
  const [showChords, setShowChords] = useState(false)
  const [simplified, setSimplified] = useState(false)
  const [hideTab, setHideTab] = useState(false)
  const [chordPopup, setChordPopup] = useState(null) // { chord, x, y }

  if (!song) return null

  const chordColors = {}
  let colorIdx = 0
  const getChordColor = chord => {
    if (!chordColors[chord]) {
      const hues = [330, 280, 200, 160, 30, 0]
      chordColors[chord] = hues[colorIdx % hues.length]
      colorIdx++
    }
    return chordColors[chord]
  }

  const transposeChordStr = ch => {
    if (!ch) return ''
    const t = transposeChord(ch, transpose)
    return simplified ? simplifyChord(t) : t
  }

  // Extrai todos os acordes únicos da música (após transposição)
  const uniqueChords = useMemo(() => {
    const set = new Set()
    const collect = lines => {
      for (const line of lines || []) {
        for (const g of line) {
          const ch = Array.isArray(g) ? g[0] : g.chord
          if (ch) {
            const tc = transposeChordStr(ch)
            if (tc) set.add(tc)
          }
        }
      }
    }
    for (const sec of song.sections || []) {
      for (const line of sec.lines || []) collect([line])
    }
    return Array.from(set)
  }, [song, transpose, simplified])

  // Verifica se a cifra tem tablatura
  const hasTab = (song.sections || []).some(sec =>
    /tab/i.test(sec.label) || (sec.lines || []).some(line =>
      line.some(g => {
        const wd = Array.isArray(g) ? g[1] : g.word
        return wd && isTabLine(wd)
      })
    )
  )

  if (viewMode === '4') {
    return renderMusicianView(song, getChordColor, chordPopup, setChordPopup, simplified, setSimplified, transposeChordStr, onToggleFavorite)
  }

  const rhythm = song.rhythm || 'Hino 4/4'
  const p = STRUM_PRESETS[rhythm] || STRUM_PRESETS['Hino 4/4']
  const strumDisplay = p ? p.s.map(s => s === 'D' ? '↓' : s === 'U' ? '↑' : s === 'X' ? '✕' : '·').join(' ') : ''

  const header = (
    <div className="song-header stage-song-header">
      <div className="stage-header-glow" />
      <div className="stage-title-row">
        <div className="stage-title-main">
          <span className="stage-kicker">Modo Palco</span>
          <div className="stitle stage-title">{song.title}</div>
          {song.artist && <div className="stage-artist">{song.artist}</div>}
        </div>
        <div className="stage-header-actions">
          <button
            className={`stage-fav-btn ${song.favorite ? 'active' : ''}`}
            onClick={() => onToggleFavorite && onToggleFavorite(song.id)}
            title={song.favorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
          >
            {song.favorite ? '★' : '☆'}
          </button>
          <button
            className="stage-share-btn"
            onClick={() => onExport && onExport()}
            title="Compartilhar cifra"
          >
            🔗
          </button>
          <div className="diagram-widget stage-diagram-widget">
            <span className="diagram-label">{uniqueChords[0] || currentKey || "G"}</span>
            <div className="diagram-grid-mock">
              <div className="diagram-dot diagram-dot-1"></div>
              <div className="diagram-dot diagram-dot-2"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="stage-meta-grid">
        <div className="stage-meta-card">
          <span>Tom</span>
          <strong>{currentKey || song.key}</strong>
          <small>Original {song.key}</small>
        </div>
        <div className="stage-meta-card">
          <span>Ritmo</span>
          <strong>{rhythm}</strong>
          <small>{strumDisplay}</small>
        </div>
        <div className="stage-meta-card">
          <span>Tempo</span>
          <strong>{song.bpm || p?.bpm || 80}</strong>
          <small>BPM</small>
        </div>
      </div>

      <div className="stage-tools-row">
        {uniqueChords.length > 0 && (
          <button
            className={`stage-tool-pill ${showChords ? 'active' : ''}`}
            onClick={() => setShowChords(p => !p)}
          >
            <span>{showChords ? '▾' : '▸'}</span>
            Acordes ({uniqueChords.length})
          </button>
        )}
        {hasTab && (
          <button
            className={`stage-tool-pill ${hideTab ? 'active' : ''}`}
            onClick={() => setHideTab(p => !p)}
            title={hideTab ? 'Mostrar tablatura' : 'Ocultar tablatura'}
          >
            <span>{hideTab ? '✓' : '○'}</span>
            Tab
          </button>
        )}
        <button
          className={`stage-tool-pill ${simplified ? 'active' : ''}`}
          onClick={() => setSimplified(p => !p)}
          title="Simplificar acordes"
        >
          <span>♭</span>
          Simplificar
        </button>
      </div>

      {showChords && (
        <div className="chord-list-grid stage-chord-grid">
          {uniqueChords.map(ch => (
            <ChordDiagram key={ch} chord={ch} size="sm" onClick={() => setChordPopup({ chord: ch })} />
          ))}
        </div>
      )}
    </div>
  )

  const transposeInStr = str =>
    str.replace(/[A-G][#b]?(m|dim|aug|sus|maj|M)?[0-9]*(?:\/[A-G][#b]?)?/g, m => transposeChordStr(m))

  const renderChordLine = (rawChordLine, key) => {
    const colored = []
    let idx = 0
    let lastChord = ''
    while (idx < rawChordLine.length) {
      const match = rawChordLine.slice(idx).match(/^[A-G][#b]?(m|dim|aug|sus|maj|M)?[0-9]*(?:\/[A-G][#b]?)?/)
      if (match) {
        const ch = match[0]
        if (ch !== lastChord) {
          colored.push(
            <span key={idx} className="ss-chord"  onClick={() => setChordPopup({ chord: ch })}>{ch}</span>
          )
          lastChord = ch
        } else {
          colored.push(<span key={idx} className="ss-space">{' '.repeat(ch.length)}</span>)
        }
        idx += ch.length
      } else {
        colored.push(<span key={idx} className="ss-space">{rawChordLine[idx]}</span>)
        idx++
      }
    }
    return colored
  }

  return (
    <div className="song-sheet-book">
      <div className="guitar-contour-left">
        <svg viewBox="0 0 30 500" preserveAspectRatio="none" style={{position:'absolute',top:0,bottom:0,left:0,width:32,height:'100%',fill:'url(#goldGrad)',pointerEvents:'none'}}>
          <defs>
            <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ecdcb9" />
              <stop offset="50%" stopColor="#e5c158" />
              <stop offset="100%" stopColor="#b38600" />
            </linearGradient>
          </defs>
          <path d="M0,0 C24,120 12,250 12,250 C12,250 24,380 0,500 L14,500 C38,380 26,250 26,250 C26,250 38,120 14,0 Z" />
          <path d="M14,0 C38,120 26,250 26,250 C26,250 38,380 14,500" fill="none" stroke="#fff" strokeWidth="1.5" opacity="0.25" />
        </svg>
      </div>
      {header}

      <div className="song-sections">
        {(song.sections || []).filter(sec => !hideTab || !/tab/i.test(sec.label)).map((sec, i) => {
          const isRef = sec.type === "refrao"
          const lines = (sec.lines || []).filter(line =>
            !hideTab || !line.some(g => {
              const wd = Array.isArray(g) ? g[1] : g.word
              return wd && isTabLine(wd)
            })
          )
          if (lines.length === 0) return null
          const body = (
            <div className="lyric-block">
              {lines.map((line, li) => (
                <div key={li} className="lyric-line">
                  {line.map((g, gi) => {
                    const ch = Array.isArray(g) ? g[0] : g.chord
                    const wd = Array.isArray(g) ? g[1] : g.word
                    const tc = transposeChordStr(ch)
                    return (
                      <span key={gi} className="wg">
                        {tc ? (
                          <span
                            className="ch ch-clickable"
                            onClick={() => setChordPopup({ chord: tc })}
                          >{tc}</span>
                        ) : (
                          <span className="ch" style={{ minHeight: "1.2em", display: "inline-block" }}></span>
                        )}
                        <span className="wd">{wd}</span>
                      </span>
                    )
                  })}
                </div>
              ))}
            </div>
          )
          return (
            <div key={i} className="sec-block">
              <div className="sec-label">{sec.label}</div>
              {isRef ? <div className="refrao-box">{body}</div> : body}
            </div>
          )
        })}
      </div>
      {chordPopup && (
        <ChordPopup chord={chordPopup.chord} onClose={() => setChordPopup(null)} />
      )}
    </div>
  )
}

function ChordPopup({ chord, onClose }) {
  const [variantIdx, setVariantIdx] = useState(0)
  const variants = getChordVariants(chord)
  const hasMultiple = variants.length > 1

  useEffect(() => { setVariantIdx(0) }, [chord])

  if (variants.length === 0) {
    return (
      <div className="chord-popup-bg" onClick={onClose}>
        <div className="chord-popup" onClick={e => e.stopPropagation()}>
          <div className="chord-popup-title">
            <span>{chord}</span>
            <button className="modal-close" onClick={onClose}>✕</button>
          </div>
          <ChordDiagram chord={chord} size="md" />
        </div>
      </div>
    )
  }

  const v = variants[variantIdx]
  const diagramData = { ...v, label: chord, root: chord, suffix: '', bass: '' }

  return (
    <div className="chord-popup-bg" onClick={onClose}>
      <div className="chord-popup chord-popup-variants" onClick={e => e.stopPropagation()}>
        <div className="chord-popup-title">
          <span>{chord}</span>
          {hasMultiple && (
            <span className="chord-popup-variant-info">{v.label}</span>
          )}
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <ChordDiagram chordData={diagramData} size="lg" />
        {hasMultiple && (
          <div className="chord-popup-actions">
            <button
              className="chord-popup-cycle-btn"
              onClick={() => setVariantIdx((variantIdx + 1) % variants.length)}
              title="Ver outras posições deste acorde"
            >
              ↻ Outras posições ({variantIdx + 1}/{variants.length})
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

function renderMusicianView(song, getChordColor, chordPopup, setChordPopup, simplified, setSimplified, transposeChordStr, onToggleFavorite) {
  const transposeInStr = str =>
    str.replace(/[A-G][#b]?(m|dim|aug|sus|maj|M)?[0-9]*(?:\/[A-G][#b]?)?/g, m => transposeChordStr(m))

  return (
    <div className="song-sheet-book">
      <div className="guitar-contour-left">
        <svg viewBox="0 0 30 500" preserveAspectRatio="none" style={{position:'absolute',top:0,bottom:0,left:0,width:32,height:'100%',fill:'url(#goldGradMusician)',pointerEvents:'none'}}>
          <defs>
            <linearGradient id="goldGradMusician" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ecdcb9" />
              <stop offset="50%" stopColor="#e5c158" />
              <stop offset="100%" stopColor="#b38600" />
            </linearGradient>
          </defs>
          <path d="M0,0 C22,120 4,250 4,250 C4,250 22,380 0,500 L12,500 C34,380 16,250 16,250 C16,250 34,120 12,0 Z" />
          <path d="M12,0 C34,120 16,250 16,250 C16,250 34,380 12,500" fill="none" stroke="#fff" strokeWidth="1" opacity="0.25" />
        </svg>
      </div>
      <div className="song-header">
        <div className="stitle-row">
          <div className="stitle">{song.title}</div>
          <button
            className={`fav-btn ${song.favorite ? "active" : ""}`}
            onClick={() => onToggleFavorite && onToggleFavorite(song.id)}
            title={song.favorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
          >
            {song.favorite ? "★" : "☆"}
          </button>
        </div>
        {song.artist && <div style={{fontSize:"0.85rem",color:"var(--text-dim)",marginBottom:4}}>{song.artist}</div>}
        <div className="smeta">
          Tom Original: <strong>{song.key}</strong>
        </div>
      </div>
      <div className="song-sections">
        {(song.sections || []).map((sec, i) => {
          const isRef = sec.type === "refrao"
          const lines = []

          for (const line of sec.lines || []) {
            let rawChordLine = ""
            let rawLyricLines = []
            let hasRaw = false

            for (const g of line) {
              const raw = (!Array.isArray(g) && g.raw) ? g.raw : ""
              if (raw) {
                hasRaw = true
                const parts = raw.split("\n")
                rawChordLine = parts[0] || ""
                rawLyricLines = parts.slice(1).filter(Boolean)
                break
              }
            }

            if (!hasRaw) {
              const text = line.map(g => Array.isArray(g) ? g[1] : g.word).join("")
              lines.push(
                <div key={lines.length} className="ms-line">
                  <div className="ms-empty" />
                  <div className="ms-lyric">{text}</div>
                </div>
              )
              continue
            }

            const chordStr = transposeInStr(rawChordLine)
            const colored = []
            let i = 0
            let lastChord = ""
            while (i < chordStr.length) {
              const match = chordStr.slice(i).match(/^[A-G][#b]?(m|dim|aug|sus|maj|M)?[0-9]*(?:\/[A-G][#b]?)?/)
              if (match) {
                const ch = match[0]
                if (ch !== lastChord) {
                  colored.push(
                    <span
                      key={i}
                      className="ms-chord ms-chord-clickable"
                      onClick={() => setChordPopup && setChordPopup({ chord: ch })}
                    >{ch}</span>
                  )
                  lastChord = ch
                } else {
                  colored.push(<span key={i} className="ms-space">{" ".repeat(ch.length)}</span>)
                }
                i += ch.length
              } else {
                colored.push(<span key={i} className="ms-space">{chordStr[i]}</span>)
                i++
              }
            }

            if (rawLyricLines.length === 0) rawLyricLines = [""]
            for (const lyricLine of rawLyricLines) {
              lines.push(
                <div key={lines.length} className="ms-line">
                  <div className="ms-chords">{colored}</div>
                  <div className="ms-lyric">{lyricLine}</div>
                </div>
              )
            }
          }

          const body = <div className="ms-block">{lines}</div>
          return (
            <div key={i} className="sec-block">
              <div className="sec-label">{sec.label}</div>
              {isRef ? <div className="refrao-box">{body}</div> : body}
            </div>
          )
        })}
      </div>
      {chordPopup && (
        <ChordPopup chord={chordPopup.chord} onClose={() => setChordPopup(null)} />
      )}
    </div>
  )}
