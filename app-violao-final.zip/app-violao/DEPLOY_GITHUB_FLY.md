# Deploy do PCifrasMusic no Fly.io via GitHub Secrets

Este projeto já está preparado para deploy automático no Fly.io usando GitHub Actions.

## 1. App configurado

O arquivo `fly.toml` usa:

```txt
app = app-cifra
primary_region = gru
internal_port = 3001
```

URL final esperada:

```txt
https://app-cifra.fly.dev
```

## 2. Secrets que você precisa adicionar no GitHub

Vá em:

```txt
GitHub > Repositório > Settings > Secrets and variables > Actions > New repository secret
```

Adicione estes secrets:

### FLY_API_TOKEN

No seu computador, depois de instalar e logar no Fly:

```bash
fly auth login
fly auth token
```

Copie o valor gerado e crie o secret:

```txt
FLY_API_TOKEN=FlyV1 ...
```

### JWT_SECRET

Gere uma chave forte. Exemplo no terminal:

```bash
openssl rand -hex 32
```

Crie o secret:

```txt
JWT_SECRET=sua_chave_gerada
```

### DOMAIN

Use:

```txt
DOMAIN=https://app-cifra.fly.dev
```

### Mercado Pago sandbox/teste

No painel do Mercado Pago Developers, use credenciais de teste/sandbox:

```txt
MP_ACCESS_TOKEN=TEST-xxxxxxxxxxxxxxxx
MP_PUBLIC_KEY=TEST-xxxxxxxxxxxxxxxx
```

## 3. Como disparar o deploy

Depois que os secrets estiverem configurados, faça push na branch `main`:

```bash
git add .
git commit -m "Aplicar tema Luthier Neon Wood e preparar deploy Fly"
git push origin main
```

O GitHub Actions vai executar automaticamente:

1. Validar secrets.
2. Criar o app `app-cifra` no Fly se ainda não existir.
3. Configurar os secrets no Fly.
4. Fazer `flyctl deploy --remote-only`.

Também é possível disparar manualmente em:

```txt
GitHub > Actions > Fly Deploy > Run workflow
```

## 4. Verificar o deploy

Após terminar, abra:

```txt
https://app-cifra.fly.dev
```

Health check:

```txt
https://app-cifra.fly.dev/api/health
```

Resposta esperada:

```json
{"ok":true}
```

## 5. Observações importantes

- Nunca coloque credenciais reais em `.env`, `README`, código ou chat.
- O workflow usa GitHub Secrets e envia para o Fly com `flyctl secrets set --stage`.
- O PWA está com Service Worker atualizado para `cifras-v35`.
- Região definida como `gru`, melhor para Brasil.
