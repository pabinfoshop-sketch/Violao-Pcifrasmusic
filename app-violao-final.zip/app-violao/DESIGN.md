# Cyber Luthier — Design System

> Tema visual unificado do PCifrasMusic. Fusão de **mogno escuro vertical** (placas de madeira quente) com **vidro translúcido glassmorphic** e **bordas neon azul-elétrico**.

---

## 1. Prompt Mestre (10 Telas)

```
A comprehensive 10-screen UI/UX mobile app design showcase for a premium
dark-mode chords application named 'PCifrasMusic'. The overall visual theme
is 'Cyber Luthier' — a unique fusion of rich, warm dark-brown mahogany
vertical wood planks and futuristic translucent glassmorphic components
with glowing electric neon-blue borders. Each screen is rendered inside a
sleek, modern smartphone standing vertically in a horizontal row on a dark,
reflective wooden studio floor under soft cinematic spotlighting.
8k resolution, photorealistic, highly detailed product presentation.
```

Esse prompt é usado para gerar mockups de apresentação e como referência
visual mestre. Toda implementação real deve respeitar os tokens definidos
abaixo.

---

## 2. Tokens visuais

Os tokens vivem em `frontend/src/cyber-luthier.css` (`:root`).

| Token | Valor | Uso |
|---|---|---|
| `--neon-shadow` | `0 0 12/30/60px rgba(0,212,255,…)` | brilho azul nos painéis |
| `--neon-border-color` | `rgba(0,212,255,0.45)` | bordas glassmorphic |
| `--glass-bg` | `rgba(28,16,12,0.72)` | overlay tuner |
| `--glass-surface` | `rgba(45,28,22,0.68)` | cards, action-btn, strum-bar |
| `--font-display` | `'Exo 2', system…` | títulos e dígitos |
| `--accent` | `#00d4ff` (definido em `index.css`) | neon principal |
| `--accent2` | azul secundário | gradientes |

**Tipografia**: `Exo 2` (corpo + dígitos) e `Rajdhani` (apoio). Carregadas
via Google Fonts no `index.html`.

**Animações principais**:
- `neonPulse` (3s) — pulsa o brilho azul (avatar de perfil, botões ativos)
- `voicePulse` (1.6s) — indicador de captura de voz
- `scanLine` (4s linear) — varredura horizontal no afinador

**Fundo**: textura de mogno em `frontend/public/wood_background.jpg` +
`wood_texture.jpg`. Listras verticais reforçadas via
`repeating-linear-gradient(90deg, …)`.

---

## 3. Mapa das 10 telas → código

| # | Tela | Arquivo principal | Estado | CSS |
|---|---|---|---|---|
| 1 | Dashboard | `App.jsx` `screen === 'songs'` | ✅ | `index.css` |
| 2 | Afinador Cromático | `components/Tuner.jsx` | ✅ | `.tuner-overlay`, `.tuner-new-*` |
| 3 | Rolagem por Voz | `App.jsx` `voiceScroll` + mic FFT | ✅ | `.voice-indicator` |
| 4 | Tela Cheia | `App.jsx` `toggleFullscreen` + `SongView.jsx` | ✅ | `.fullscreen-*` |
| 5 | Menu Compartilhar | Modal genérico (`components/Modal.jsx`) | ✅ | `.share-sheet`, `.share-title` |
| 6 | Perfil & Sync | `components/AuthModal.jsx` | ✅ | `.auth-modal`, `.auth-panel` |
| 7 | Metrônomo | `components/StrumBar.jsx` + `MetronomePanel.jsx` | ✅ | `.strum-bar`, `.strum-beat`, `.metronome-*` |
| 8 | Repertórios (Setlist) | `App.jsx` setlists | ✅ | `.setlist-nav`, `.setlist-card`, `.sn-btn` |
| 9 | Editor de Cifras | `App.jsx` `showEditor` | ✅ | `.edit-overlay`, `.edit-topbar`, `textarea` |
| 10 | Equalizador | `App.jsx` `showEqualizer` | ✅ | `.equalizer-panel`, `input[type=range]` |

---

## 4. Especificação por tela

### 1. Dashboard
Topbar com título com gradiente neon (`.topbar-title`). Cards de música em
glass-surface com capa real (`public/cover_*.jpg`). Quatro botões flutuantes
no topo (afinador, metrônomo, EQ, perfil). Footer com nav-tabs
glassmorphic.

### 2. Afinador Cromático
Overlay full-screen com fundo mogno listrado, agulha animada com
`scanLine`, frequência em gradiente neon, dots clicáveis para corda
(`.tuner-new-dot.active` recebe `neonPulse`). Botão fechar com halo azul.

### 3. Rolagem por Voz
Análise FFT do microfone (`AnalyserNode`) detecta sustentação de voz e
empurra o scroll do conteúdo. Indicador `.voice-indicator` pulsa com
`voicePulse`. Tolerante a `prefers-reduced-motion`.

### 4. Tela Cheia
`document.documentElement.requestFullscreen()`. Esconde nav-tabs e topbar,
maximiza letra. Atalho `F`. SongView renderiza acordes inline com
`.chord` em neon.

### 5. Menu Compartilhar
Bottom-sheet glass com `backdrop-filter:blur(28px)`, borda neon e
`box-shadow: var(--neon-shadow)`. Opções: WhatsApp, copiar link, exportar
PDF, salvar localmente.

### 6. Perfil & Sincronização
Modal de autenticação com avatar circular pulsante (`neonPulse`). Status
de sincronização com backend (`backend/src/auth.js`,
`backend/src/mercadopago.js`).

### 7. Metrônomo (novo painel)
`components/MetronomePanel.jsx`. BPM grande em neon, dial radial,
batidas como `.strum-beat` (escala 1.25× + halo quando ativas), seletor
de compasso (2/4, 3/4, 4/4, 6/8), tap-tempo, acento no primeiro beat.

### 8. Repertórios
Lista de setlists em cards glass com borda neon ao hover/active. Ações:
criar, renomear, deletar, adicionar/remover música, reordenar. Topbar
`setlist-nav` com blur 14px.

### 9. Editor de Cifras
Overlay full-screen com `textarea` glass (caret em `--accent`). Suporte
a acordes inline `[Am]`, transpose, salvar. Topbar com ações.

### 10. Equalizador
Painel glass com 8–10 sliders verticais (`input[type=range]`), presets
(Acústico, Voz, Loud, Flat), bypass. Thumb com halo neon.

---

## 5. Regras de implementação

1. **Nunca** misturar paleta — só mogno + neon-azul (`#00d4ff`/`#00aaff`).
   Evitar verdes, vermelhos puros ou pasteis fora de avisos de estado.
2. Todo painel sobreposto precisa de `backdrop-filter: blur(...)` + borda
   neon + `var(--neon-shadow)`.
3. Toda animação precisa respeitar `@media (prefers-reduced-motion: reduce)`.
4. Tipografia: `Exo 2` para tudo que é display/UI; só corpo longo de cifra
   usa monospace.
5. Cores semânticas (erro/aviso) só em toasts e dialogs, nunca como
   destaque permanente.

---

## 6. Assets

- `frontend/public/wood_background.jpg` — fundo mogno principal
- `frontend/public/wood_texture.jpg` — tile para overlays
- `frontend/public/cover_*.jpg` — capas de músicas padrão
- `frontend/public/splash_instruments.png` — splash PWA
- `frontend/public/icons/icon-*.png` — ícones PWA

---

## 7. Roadmap visual

- [ ] Mockups 8k photorealistic dos 10 telefones em fila (gerar via IA usando
      o prompt mestre acima)
- [ ] Vídeo demo de 30s percorrendo as 10 telas
- [ ] Variação clara (modo dia) — **opcional**, pode quebrar identidade
